#!/usr/bin/env bash
set -Eeuo pipefail
echo "=== NETWORK INTERFACE COUNTERS ==="
if command -v ip >/dev/null 2>&1; then
  ip -s link
else
  echo "Arahan ip tidak dijumpai."
fi
echo
echo "Nota: kaunter ini menunjukkan jumlah pada interface sejak boot; belum membezakan penggunaan setiap akaun."
