#!/usr/bin/env bash
set -Eeuo pipefail
echo "=== KERAMAT VPN / SYSTEM INFORMATION ==="
echo "OS: $(. /etc/os-release; echo "$PRETTY_NAME")"
echo "Kernel: $(uname -r)"
echo "Uptime: $(uptime -p)"
echo
free -h
echo
df -h /
echo
ip -brief address
